Note:

TVGuide.xhtml may not open as shown in the book depending upon your browser. It may appear as an xml document.

TVGuide_2.xhtml is identical except that the following line has been removed:

<?xml version="1.0" encoding="ISO-8859-1"?>

If TVGuide.xhtml doesnot appear in your browser as shown in the book, then TVGuide_2.xhtml should.

