function explainParseError(error) {
	return error.reason + '[' + error.url + ': line ' + error.line + ', col ' + error.linepos + ']';
}

function getDOMFromFile(File) {
      DOM = new ActiveXObject('Msxml2.FreeThreadedDOMDocument');
      DOM.async = false;
      DOM.load(File);
      if (DOM.parseError.errorCode != 0) {
        alert('Error parsing File:\n' + explainParseError(DOM.parseError));
        return;
      }
	  return DOM;
}

function getDOMFromXML(XML) {
      DOM = new ActiveXObject('Msxml2.FreeThreadedDOMDocument');
      DOM.async = false;
      DOM.loadXML(XML);
      if (DOM.parseError.errorCode != 0) {
        alert('Error parsing XML:\n' + explainParseError(DOM.parseError));
        return;
      }
	  return DOM;
}

function getProcessor(XMLFile, XSLFile) {
	return getProcessorFromDOMs(getDOMFromFile(XMLFile), getDOMFromFile(XSLFile));
}

function getProcessorFromDOMs(XMLDOM, XSLTDOM) {
	  try {
		  XSLStylesheet = new ActiveXObject('Msxml2.XSLTemplate');
		  XSLStylesheet.stylesheet = XSLTDOM;
		  XSLTProcessor = XSLStylesheet.createProcessor();
		  XSLTProcessor.input = XMLDOM;
		  return XSLTProcessor;
	  } catch (exception) {
		alert('Error creating processor:\n' + exception.description);
		return;
	  }
}

function loadTransformedXML(XSLTProcessor, frame) {
      try {
    	 XSLTProcessor.transform();
         frame.document.open();
         frame.document.write(XSLTProcessor.output);
         frame.document.close();
      } catch (exception) {
		alert('Error transforming XML:\n' + exception.description);
	  }		
}